package pwr.algorithm.details.impl;

import java.util.ArrayList;
import java.util.List;

import org.jzy3d.plot3d.pipelines.NotImplementedException;

import pwr.algorithm.Range;
import pwr.algorithm.Specimen;
import pwr.algorithm.details.facade.IMutationOperator;

public class MutationGradient implements IMutationOperator{

	public MutationGradient(List<Range> ranges) {
		throw new NotImplementedException();
	}

	@Override
	public ArrayList<Specimen> mutate(ArrayList<Specimen> specimens, Double pm, Integer iteration) {
		throw new NotImplementedException();
	}

}
