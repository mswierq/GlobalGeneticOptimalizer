package pwr.algorithm.details.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import pwr.algorithm.Range;
import pwr.algorithm.Specimen;
import pwr.algorithm.details.facade.ICrossOperator;

public class CrossSimple implements ICrossOperator{
	private ArrayList<Specimen> choosenSpecimens;
	private Random randomNumbersGenerator;
	private List<Range> ranges;
	
	public CrossSimple(ArrayList<Range> ranges) {
		choosenSpecimens = new ArrayList<Specimen>();
		this.randomNumbersGenerator = new Random();
		this.ranges = ranges;
	}
	
	@Override
	public void cross(ArrayList<Specimen> specimens, Double pc) {
		choosenSpecimens = new ArrayList<Specimen>();
		Iterator<Specimen> sItr = specimens.iterator();
		while(sItr.hasNext()){
			Specimen s = sItr.next();
			Double r = randomNumbersGenerator.nextDouble();
			if(r < pc) {
				choosenSpecimens.add(s);
			}
		}
		
		sItr = choosenSpecimens.iterator();
		while(sItr.hasNext()) {
			specimens.remove(sItr.next());
		}
		
		if(choosenSpecimens.size() % 2 != 0) {
			specimens.add(choosenSpecimens.get(choosenSpecimens.size()-1));
			choosenSpecimens.remove(choosenSpecimens.size()-1);
		}
		
		while(choosenSpecimens.size() > 0) {
			int csSize = choosenSpecimens.size();
			Specimen specimenA = choosenSpecimens.get((int)Math.round((csSize-1)*randomNumbersGenerator.nextDouble()));
			choosenSpecimens.remove(specimenA);
			Specimen specimenB = choosenSpecimens.get((int)Math.round((csSize-2)*randomNumbersGenerator.nextDouble()));
			choosenSpecimens.remove(specimenB);
			crossPair(specimenA,specimenB);
			specimens.add(specimenA);
			specimens.add(specimenB);
		}
	}

	private void crossPair(Specimen specimenA, Specimen specimenB) {
		int chSize = specimenA.getChromosome().size();
		int crossPosition = (int) (chSize*randomNumbersGenerator.nextDouble());
		
		ArrayList<Double> newChromosomeA = new ArrayList<Double>(specimenB.getChromosome().subList(0, crossPosition));
		ArrayList<Double> newChromosomeB = new ArrayList<Double>(specimenA.getChromosome().subList(0, crossPosition));
		Double a = randomNumbersGenerator.nextDouble();
		
		for(int i = crossPosition; i < chSize; i++) {
			newChromosomeA.add(specimenA.getChromosome().get(i)*a + specimenB.getChromosome().get(i)*(1-a));
			newChromosomeB.add(specimenB.getChromosome().get(i)*a + specimenA.getChromosome().get(i)*(1-a));
		}
		
//		Zaimplementowa�em t� opcj� ze sprawdzaniem dziedziny, ale stary... nigdy (a robi�em kilka symulacji po milion iteracji)
//		nie zdarzy�o si� tak, �eby nowy gen znajdowa� si� poza dziedzin�
//		Double newGeneA, newGeneB;
//		
//		for(int i = crossPosition; i < chSize; i++) {
//			newGeneA = specimenA.getChromosome().get(i)*a + specimenB.getChromosome().get(i)*(1-a);
//			newGeneB = specimenB.getChromosome().get(i)*a + specimenA.getChromosome().get(i)*(1-a);
//			
//			if(ranges.get(i).contains(newGeneA) && ranges.get(i).contains(newGeneB)){
//				newChromosomeA.add(newGeneA);
//				newChromosomeB.add(newGeneB);	
//			} else {
//				throw new NotImplementedException();
//			}
//		}
		
		specimenA.setChromosome(newChromosomeA);
		specimenB.setChromosome(newChromosomeB);
	}
}
