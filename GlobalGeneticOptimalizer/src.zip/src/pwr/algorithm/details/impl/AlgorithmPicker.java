package pwr.algorithm.details.impl;

import java.util.ArrayList;
import java.util.List;

import pwr.algorithm.ECross;
import pwr.algorithm.EMutation;
import pwr.algorithm.Range;
import pwr.algorithm.details.facade.ICrossOperator;
import pwr.algorithm.details.facade.IMutationOperator;

public class AlgorithmPicker {

	public static ICrossOperator getCrossOperator(ECross crossAlgorithm, ArrayList<Range> range){
		switch(crossAlgorithm){
			case simple: return new CrossSimple(range);
			case arithmetic : return new CrossArithmetic(); 
			default: return null;
		}
	}
	
	public static IMutationOperator getMutationOperator(EMutation mutationAlgorithm, List<Range> ranges, Integer iterations){
		switch(mutationAlgorithm){
		case equal: return new MutationEqual(ranges);
		case unequal: return new MutationUnequal(ranges, iterations);
		case gradient: return new MutationGradient(ranges);
		default: return null;
		}
	}
}
