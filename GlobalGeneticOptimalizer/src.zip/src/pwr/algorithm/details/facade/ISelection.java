package pwr.algorithm.details.facade;

import java.util.ArrayList;

import pwr.algorithm.Specimen;

public interface ISelection {
	public ArrayList<Specimen> select(ArrayList<Specimen> specimens);
}
