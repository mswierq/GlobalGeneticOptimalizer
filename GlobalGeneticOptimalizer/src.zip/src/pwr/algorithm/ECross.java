package pwr.algorithm;

public enum ECross {
	simple, arithmetic;
}
