package pwr.algorithm;

public enum EMutation {
	equal, unequal, gradient;
}
